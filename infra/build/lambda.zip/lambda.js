"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/lambda.ts
var lambda_exports = {};
__export(lambda_exports, {
  PULL_PATH: () => PULL_PATH,
  handler: () => handler
});
module.exports = __toCommonJS(lambda_exports);
var import_node_crypto = require("node:crypto");

// src/errors.ts
var ProviderError = class extends Error {
  static {
    __name(this, "ProviderError");
  }
  constructor(message) {
    super(message);
    this.name = new.target.name;
  }
};
var BadRequestError = class extends ProviderError {
  static {
    __name(this, "BadRequestError");
  }
  status = 400;
  code = "BAD_REQUEST";
};
var UnauthorizedError = class extends ProviderError {
  static {
    __name(this, "UnauthorizedError");
  }
  status = 401;
  code = "UNAUTHORIZED";
  constructor() {
    super("The X-Require-Whisk-Auth header is missing or wrong.");
  }
};
var RouteNotFoundError = class extends ProviderError {
  static {
    __name(this, "RouteNotFoundError");
  }
  status = 404;
  code = "NOT_FOUND";
  constructor(path, served) {
    super(`Nothing is served at ${path}. Expected ${served}.`);
  }
};
var MethodNotAllowedError = class extends ProviderError {
  static {
    __name(this, "MethodNotAllowedError");
  }
  status = 405;
  code = "METHOD_NOT_ALLOWED";
  constructor(used, allowed) {
    super(`Method ${used.toUpperCase()} is not allowed. Expected one of ${allowed.join(", ").toUpperCase()}.`);
  }
};
var AerodromeNotFoundError = class extends ProviderError {
  static {
    __name(this, "AerodromeNotFoundError");
  }
  status = 404;
  code = "AERODROME_NOT_FOUND";
  constructor(icao) {
    super(`OpenStreetMap has no aerodrome tagged with the ICAO code ${icao}.`);
  }
};
var OverpassUnavailableError = class extends ProviderError {
  static {
    __name(this, "OverpassUnavailableError");
  }
  status = 502;
  code = "OVERPASS_UNAVAILABLE";
  constructor() {
    super("Every Overpass mirror is unavailable.");
  }
};
var ResultTooLargeError = class extends ProviderError {
  static {
    __name(this, "ResultTooLargeError");
  }
  status = 413;
  code = "RESULT_TOO_LARGE";
  constructor(bytes, limit) {
    super(
      `The airport data is ${Math.round(bytes / 1024)} kB, over the ${Math.round(limit / 1024)} kB a function result may carry. Narrow it with include, for example include=runways,terminals,parkingPositions.`
    );
  }
};

// src/logger.ts
var SEVERITY = {
  verbose: 10,
  debug: 20,
  log: 30,
  warn: 40,
  error: 50,
  fatal: 60
};
var DEFAULT_LEVEL = "log";
var PREFIX = "OSM";
var plain = /* @__PURE__ */ __name((text) => text, "plain");
function ansi(open) {
  return (text) => `\x1B[${open}m${text}\x1B[39m`;
}
__name(ansi, "ansi");
var COLORS = {
  verbose: ansi("96"),
  debug: ansi("95"),
  log: ansi("32"),
  warn: ansi("33"),
  error: ansi("31"),
  fatal: /* @__PURE__ */ __name((text) => `\x1B[1m${text}\x1B[0m`, "fatal")
};
var CONTEXT_COLOR = ansi("38;5;3");
function isLevel(value) {
  return value in SEVERITY;
}
__name(isLevel, "isLevel");
function threshold() {
  const configured = (process.env.LOG_LEVEL ?? "").toLowerCase();
  return SEVERITY[isLevel(configured) ? configured : DEFAULT_LEVEL];
}
__name(threshold, "threshold");
function colored() {
  return process.stdout.isTTY === true && !process.env.NO_COLOR;
}
__name(colored, "colored");
function timestamp() {
  return (/* @__PURE__ */ new Date()).toLocaleString("en-US", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "numeric",
    minute: "numeric",
    second: "numeric"
  });
}
__name(timestamp, "timestamp");
function format(level, context, message) {
  const paint = colored() ? COLORS[level] : plain;
  const contextPaint = colored() ? CONTEXT_COLOR : plain;
  const pid = paint(`[${PREFIX}] ${process.pid}  - `);
  const label = paint(level.toUpperCase().padStart(7, " "));
  return `${pid}${timestamp()} ${label} ${contextPaint(`[${context}] `)}${paint(message)}`;
}
__name(format, "format");
function write(level, context, message, stack) {
  if (SEVERITY[level] < threshold()) {
    return;
  }
  const stream = level === "error" || level === "fatal" ? process.stderr : process.stdout;
  stream.write(`${format(level, context, message)}
${stack ? `${stack}
` : ""}`);
}
__name(write, "write");
function describeError(error, depth = 3) {
  if (!(error instanceof Error)) {
    try {
      return `Non-error thrown: ${JSON.stringify(error)}`;
    } catch {
      return `Non-error thrown: ${String(error)}`;
    }
  }
  const head = `${error.name}: ${error.message}`;
  if (depth <= 1 || error.cause === void 0 || error.cause === null) {
    return head;
  }
  return `${head} (caused by: ${describeError(error.cause, depth - 1)})`;
}
__name(describeError, "describeError");
function stackOf(error) {
  return error instanceof Error ? error.stack : void 0;
}
__name(stackOf, "stackOf");
var Logger = class {
  constructor(context) {
    this.context = context;
  }
  context;
  static {
    __name(this, "Logger");
  }
  verbose(message) {
    write("verbose", this.context, message);
  }
  debug(message) {
    write("debug", this.context, message);
  }
  log(message) {
    write("log", this.context, message);
  }
  warn(message) {
    write("warn", this.context, message);
  }
  error(message, stack) {
    write("error", this.context, message, stack);
  }
  fatal(message, stack) {
    write("fatal", this.context, message, stack);
  }
};

// src/client.ts
var AEROWAY_FEATURES = ["runway", "terminal", "parking_position", "gate"];
var FALLBACK_RADIUS_METERS = 8e3;
var REQUEST_TIMEOUT_MS = 6e4;
var ATTEMPTS_PER_MIRROR = 2;
var BACKOFF_MS = 1e3;
var DEADLINE_MS = 21e4;
var DEFAULT_OVERPASS_URLS = [
  "https://overpass-api.de/api/interpreter",
  "https://overpass.kumi.systems/api/interpreter",
  "https://maps.mail.ru/osm/tools/overpass/api/interpreter",
  "https://overpass.private.coffee/api/interpreter"
];
var RETRYABLE_STATUS = /* @__PURE__ */ new Set([429, 502, 503, 504]);
var delay = /* @__PURE__ */ __name((ms) => new Promise((resolve) => setTimeout(resolve, ms)), "delay");
function areaQuery(icao) {
  const features = AEROWAY_FEATURES.map((value) => `  nwr(area.f)["aeroway"="${value}"];`).join("\n");
  return [
    "[out:json][timeout:60];",
    `nwr["aeroway"="aerodrome"]["icao"="${icao}"]->.a;`,
    ".a map_to_area->.f;",
    "(",
    features,
    ")->.feat;",
    "(.a; .feat;);",
    "out geom;"
  ].join("\n");
}
__name(areaQuery, "areaQuery");
function aroundQuery(icao) {
  const features = AEROWAY_FEATURES.map(
    (value) => `  nwr(around.a:${FALLBACK_RADIUS_METERS})["aeroway"="${value}"];`
  ).join("\n");
  return [
    "[out:json][timeout:60];",
    `nwr["aeroway"="aerodrome"]["icao"="${icao}"]->.a;`,
    "(",
    features,
    ")->.feat;",
    "(.a; .feat;);",
    "out geom;"
  ].join("\n");
}
__name(aroundQuery, "aroundQuery");
function hasFeatures(elements) {
  return elements.some((element) => {
    const aeroway = element.tags?.aeroway;
    return aeroway !== void 0 && AEROWAY_FEATURES.includes(aeroway);
  });
}
__name(hasFeatures, "hasFeatures");
var OverpassClient = class _OverpassClient {
  static {
    __name(this, "OverpassClient");
  }
  logger = new Logger(_OverpassClient.name);
  urls;
  userAgent;
  constructor(options) {
    this.urls = options.urls;
    this.userAgent = options.userAgent;
  }
  /**
   * Every element Overpass holds for one ICAO code. An empty array means OSM
   * knows no aerodrome by that code — a caller concern, not a failure here.
   */
  async queryAerodrome(icaoCode) {
    const icao = icaoCode.toUpperCase();
    const deadline = Date.now() + DEADLINE_MS;
    const elements = await this.run(areaQuery(icao), deadline);
    if (hasFeatures(elements) || elements.length === 0) {
      return elements;
    }
    this.logger.debug(`${icao} enclosed no aeroway features; retrying within ${FALLBACK_RADIUS_METERS}m of it.`);
    return this.run(aroundQuery(icao), deadline);
  }
  async run(query, deadline) {
    for (const [index, url] of this.urls.entries()) {
      try {
        return await this.attempt(url, query, deadline);
      } catch (error) {
        if (Date.now() >= deadline) {
          this.logger.error(`Gave up on Overpass after ${DEADLINE_MS}ms: ${describeError(error)}`);
          throw new OverpassUnavailableError();
        }
        if (index < this.urls.length - 1) {
          this.logger.warn(`Overpass mirror ${url} is unavailable; trying the next one.`);
        } else {
          this.logger.error(`Every Overpass mirror failed. The last said: ${describeError(error)}`);
        }
      }
    }
    throw new OverpassUnavailableError();
  }
  async attempt(url, query, deadline) {
    let lastError;
    for (let attempt = 1; attempt <= ATTEMPTS_PER_MIRROR; attempt++) {
      if (Date.now() >= deadline) {
        throw lastError ?? new OverpassUnavailableError();
      }
      const startedAt = Date.now();
      try {
        const response = await fetch(url, {
          method: "POST",
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
            "User-Agent": this.userAgent
          },
          body: new URLSearchParams({ data: query }),
          signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS)
        });
        if (RETRYABLE_STATUS.has(response.status)) {
          lastError = new Error(`${url} answered ${response.status}`);
        } else if (!response.ok) {
          throw new Error(`${url} answered ${response.status}: ${(await response.text()).slice(0, 200)}`);
        } else {
          const payload = await response.json();
          const elements = payload.elements ?? [];
          this.logger.debug(`${url} returned ${elements.length} element(s) in ${Date.now() - startedAt}ms.`);
          return elements;
        }
      } catch (error) {
        lastError = error;
      }
      if (attempt < ATTEMPTS_PER_MIRROR) {
        const backoff = BACKOFF_MS * 2 ** (attempt - 1);
        this.logger.warn(`Attempt ${attempt} on ${url} failed: ${describeError(lastError)}. Retrying in ${backoff}ms.`);
        await delay(backoff);
      }
    }
    throw lastError ?? new OverpassUnavailableError();
  }
};

// src/geo.ts
var EARTH_RADIUS_METERS = 6371e3;
function toRadians(degrees) {
  return degrees * Math.PI / 180;
}
__name(toRadians, "toRadians");
function toDegrees(radians) {
  return radians * 180 / Math.PI;
}
__name(toDegrees, "toDegrees");
function ringToCoordinates(geometry) {
  return geometry.map((point) => ({ longitude: point.lon, latitude: point.lat }));
}
__name(ringToCoordinates, "ringToCoordinates");
var ENDPOINT_MATCH_EPSILON = 1e-7;
function coordinatesEqual(a, b) {
  return Math.abs(a.longitude - b.longitude) <= ENDPOINT_MATCH_EPSILON && Math.abs(a.latitude - b.latitude) <= ENDPOINT_MATCH_EPSILON;
}
__name(coordinatesEqual, "coordinatesEqual");
function isClosed(ring) {
  return ring.length >= 4 && coordinatesEqual(ring[0], ring[ring.length - 1]);
}
__name(isClosed, "isClosed");
function assembleRings(segments) {
  const remaining = segments.filter((segment) => segment.length >= 2).map((segment) => segment.slice());
  const rings = [];
  while (remaining.length > 0) {
    let ring = remaining.shift();
    let extended = true;
    while (extended && !isClosed(ring)) {
      extended = false;
      for (let i = 0; i < remaining.length; i += 1) {
        const segment = remaining[i];
        const ringStart = ring[0];
        const ringEnd = ring[ring.length - 1];
        const segmentStart = segment[0];
        const segmentEnd = segment[segment.length - 1];
        if (coordinatesEqual(ringEnd, segmentStart)) {
          ring = ring.concat(segment.slice(1));
        } else if (coordinatesEqual(ringEnd, segmentEnd)) {
          ring = ring.concat(segment.slice(0, -1).reverse());
        } else if (coordinatesEqual(ringStart, segmentEnd)) {
          ring = segment.slice(0, -1).concat(ring);
        } else if (coordinatesEqual(ringStart, segmentStart)) {
          ring = segment.slice(1).reverse().concat(ring);
        } else {
          continue;
        }
        remaining.splice(i, 1);
        extended = true;
        break;
      }
    }
    rings.push(ring);
  }
  return rings;
}
__name(assembleRings, "assembleRings");
function planarRingArea(ring) {
  if (ring.length < 3) return 0;
  const scale = Math.cos(toRadians(ring[0].latitude));
  let area = 0;
  for (let i = 0, j = ring.length - 1; i < ring.length; j = i, i += 1) {
    area += ring[j].longitude * scale * ring[i].latitude - ring[i].longitude * scale * ring[j].latitude;
  }
  return Math.abs(area) / 2;
}
__name(planarRingArea, "planarRingArea");
function largestRing(rings) {
  let best;
  let bestArea = -Infinity;
  for (const ring of rings) {
    const area = planarRingArea(ring);
    if (area > bestArea) {
      bestArea = area;
      best = ring;
    }
  }
  return best;
}
__name(largestRing, "largestRing");
function haversineMeters(a, b) {
  const dLat = toRadians(b.latitude - a.latitude);
  const dLon = toRadians(b.longitude - a.longitude);
  const lat1 = toRadians(a.latitude);
  const lat2 = toRadians(b.latitude);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLon / 2) ** 2;
  return 2 * EARTH_RADIUS_METERS * Math.asin(Math.min(1, Math.sqrt(h)));
}
__name(haversineMeters, "haversineMeters");
function initialBearing(from, to) {
  const lat1 = toRadians(from.latitude);
  const lat2 = toRadians(to.latitude);
  const dLon = toRadians(to.longitude - from.longitude);
  const y = Math.sin(dLon) * Math.cos(lat2);
  const x = Math.cos(lat1) * Math.sin(lat2) - Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLon);
  return (toDegrees(Math.atan2(y, x)) + 360) % 360;
}
__name(initialBearing, "initialBearing");
function angularDistance(a, b) {
  const diff = Math.abs((a - b) % 360 + 360) % 360;
  return Math.min(diff, 360 - diff);
}
__name(angularDistance, "angularDistance");
function polygonCentroid(ring) {
  const points = ring.length > 1 && ring[0].longitude === ring[ring.length - 1].longitude && ring[0].latitude === ring[ring.length - 1].latitude ? ring.slice(0, -1) : ring;
  const sum = points.reduce(
    (acc, point) => ({
      longitude: acc.longitude + point.longitude,
      latitude: acc.latitude + point.latitude
    }),
    { longitude: 0, latitude: 0 }
  );
  return {
    longitude: sum.longitude / points.length,
    latitude: sum.latitude / points.length
  };
}
__name(polygonCentroid, "polygonCentroid");
function nearestByPoint(point, candidates, locate) {
  let best;
  let bestDistance = Infinity;
  for (const candidate of candidates) {
    const distance = haversineMeters(point, locate(candidate));
    if (distance < bestDistance) {
      bestDistance = distance;
      best = candidate;
    }
  }
  return best;
}
__name(nearestByPoint, "nearestByPoint");
function pointInRing(point, ring) {
  let inside = false;
  for (let i = 0, j = ring.length - 1; i < ring.length; j = i, i += 1) {
    const a = ring[i];
    const b = ring[j];
    const crosses = a.latitude > point.latitude !== b.latitude > point.latitude && point.longitude < (b.longitude - a.longitude) * (point.latitude - a.latitude) / (b.latitude - a.latitude) + a.longitude;
    if (crosses) inside = !inside;
  }
  return inside;
}
__name(pointInRing, "pointInRing");
function segmentDistanceMeters(point, a, b) {
  const scale = Math.cos(toRadians(point.latitude));
  const px = point.longitude * scale;
  const py = point.latitude;
  const ax = a.longitude * scale;
  const ay = a.latitude;
  const bx = b.longitude * scale;
  const by = b.latitude;
  const lengthSquared = (bx - ax) ** 2 + (by - ay) ** 2;
  const t = lengthSquared === 0 ? 0 : Math.max(0, Math.min(1, ((px - ax) * (bx - ax) + (py - ay) * (by - ay)) / lengthSquared));
  const nearest = {
    longitude: (ax + t * (bx - ax)) / scale,
    latitude: ay + t * (by - ay)
  };
  return haversineMeters(point, nearest);
}
__name(segmentDistanceMeters, "segmentDistanceMeters");
function distanceToPolygonMeters(point, ring) {
  if (ring.length === 1) return haversineMeters(point, ring[0]);
  if (pointInRing(point, ring)) return 0;
  let best = Infinity;
  for (let i = 0, j = ring.length - 1; i < ring.length; j = i, i += 1) {
    best = Math.min(best, segmentDistanceMeters(point, ring[j], ring[i]));
  }
  return best;
}
__name(distanceToPolygonMeters, "distanceToPolygonMeters");
function nearestByPolygon(point, candidates, locate) {
  let best;
  let bestDistance = Infinity;
  for (const candidate of candidates) {
    const distance = distanceToPolygonMeters(point, locate(candidate));
    if (distance < bestDistance) {
      bestDistance = distance;
      best = candidate;
    }
  }
  return best;
}
__name(nearestByPolygon, "nearestByPolygon");
function thresholdEndpointFor(headingDegrees, ring) {
  const start = ring[0];
  const end = ring[ring.length - 1];
  const startToEnd = angularDistance(initialBearing(start, end), headingDegrees);
  const endToStart = angularDistance(initialBearing(end, start), headingDegrees);
  return startToEnd <= endToStart ? start : end;
}
__name(thresholdEndpointFor, "thresholdEndpointFor");

// src/transform/airport.data.ts
var SOURCE = "OpenStreetMap via Overpass";
var FALLBACK_TERMINAL_SHORT_NAME = "MAIN";
function assembleAirportData(transformed) {
  const terminals = transformed.terminals.map((entry) => entry.terminal);
  const located = transformed.terminals.map((entry) => ({
    shortName: entry.terminal.shortName,
    outline: entry.terminal.shape ?? [entry.centroid]
  }));
  const standPoints = [
    ...transformed.parkingPositions.map((position) => position.coordinates),
    ...transformed.gates.map((gate) => gate.coordinates)
  ];
  if (standPoints.length > 0 && located.length === 0) {
    terminals.push({
      shortName: FALLBACK_TERMINAL_SHORT_NAME,
      fullName: "Main Terminal",
      averageTaxiTime: 0,
      operatorCodes: [],
      text: "Auto-generated fallback terminal hosting OSM features with no mapped terminal."
    });
    located.push({
      shortName: FALLBACK_TERMINAL_SHORT_NAME,
      outline: [polygonCentroid(standPoints)]
    });
  }
  const nearestTerminal = /* @__PURE__ */ __name((point) => nearestByPolygon(point, located, (entry) => entry.outline)?.shortName ?? FALLBACK_TERMINAL_SHORT_NAME, "nearestTerminal");
  const parkingPositions = transformed.parkingPositions.map((position) => ({
    ...position,
    terminal: nearestTerminal(position.coordinates)
  }));
  const gates = transformed.gates.map((gate) => ({
    ...gate,
    terminal: nearestTerminal(gate.coordinates)
  }));
  const hostingTerminals = /* @__PURE__ */ new Set([
    ...parkingPositions.map((position) => position.terminal),
    ...gates.map((gate) => gate.terminal)
  ]);
  const data = {
    icaoCode: transformed.icaoCode,
    name: transformed.name,
    source: SOURCE,
    runways: transformed.runways,
    terminals: terminals.filter((terminal) => hostingTerminals.has(terminal.shortName)),
    parkingPositions,
    gates
  };
  if (transformed.location) {
    data.location = transformed.location;
  }
  if (transformed.shape) {
    data.shape = transformed.shape;
  }
  return data;
}
__name(assembleAirportData, "assembleAirportData");
function isEmpty(data) {
  return !data.location && !data.shape && data.runways.length === 0 && data.terminals.length === 0 && data.parkingPositions.length === 0 && data.gates.length === 0;
}
__name(isEmpty, "isEmpty");

// src/transform/names.ts
var MAX_SHORT_NAME_LENGTH = 8;
var AIRPORT_SUFFIX = /^(.+?)(\s+International)?\s+Airport$/i;
var NOTHING_BUT_GENERIC = /^international$/i;
var TERMINAL_DESIGNATOR = /^terminal\s+(\S+)$/i;
function shortenAirportName(name) {
  const trimmed = name.trim();
  const match = AIRPORT_SUFFIX.exec(trimmed);
  if (!match || NOTHING_BUT_GENERIC.test(match[1])) {
    return trimmed;
  }
  return match[2] ? `${match[1]} Intl` : match[1];
}
__name(shortenAirportName, "shortenAirportName");
function designatorShortName(name) {
  const match = TERMINAL_DESIGNATOR.exec(name.trim());
  if (!match) {
    return void 0;
  }
  const designator = match[1];
  if (new RegExp("^\\p{L}$", "u").test(designator)) {
    return designator.toUpperCase();
  }
  if (/^\d+$/.test(designator)) {
    const shortName = `T${designator}`;
    return shortName.length <= MAX_SHORT_NAME_LENGTH ? shortName : void 0;
  }
  return void 0;
}
__name(designatorShortName, "designatorShortName");
function compactName(name) {
  const compact = name.split(/\s+/).map((token) => token.replace(/[^A-Za-z0-9]/g, "")).filter(Boolean).map((token) => /\d/.test(token) ? token : token[0]).join("");
  return compact.toUpperCase().slice(0, MAX_SHORT_NAME_LENGTH) || "T";
}
__name(compactName, "compactName");
function deriveTerminalShortName(ref, name) {
  const designator = designatorShortName(name);
  if (designator) {
    return designator;
  }
  if (ref) {
    const code = ref.split(/[;,/]/)[0].replace(/[^A-Za-z0-9]/g, "").toUpperCase().slice(0, MAX_SHORT_NAME_LENGTH);
    if (code) {
      return code;
    }
  }
  return compactName(name);
}
__name(deriveTerminalShortName, "deriveTerminalShortName");
function uniqueShortName(base, taken) {
  if (!taken.has(base)) {
    return base;
  }
  for (let suffix = 2; suffix < 100; suffix++) {
    const candidate = base.slice(0, MAX_SHORT_NAME_LENGTH - String(suffix).length) + suffix;
    if (!taken.has(candidate)) {
      return candidate;
    }
  }
  return base;
}
__name(uniqueShortName, "uniqueShortName");

// src/transform/airport.transform.ts
var MAX_GATE_STAND_DISTANCE_METERS = 100;
function toNumber(value) {
  if (value === void 0) {
    return void 0;
  }
  const parsed = parseFloat(value);
  return Number.isFinite(parsed) ? parsed : void 0;
}
__name(toNumber, "toNumber");
function toInteger(value) {
  const parsed = toNumber(value);
  return parsed === void 0 ? void 0 : Math.round(parsed);
}
__name(toInteger, "toInteger");
function nodeLocation(element) {
  if (element.lat !== void 0 && element.lon !== void 0) {
    return { longitude: element.lon, latitude: element.lat };
  }
  return void 0;
}
__name(nodeLocation, "nodeLocation");
function elementRing(element) {
  if (element.geometry && element.geometry.length > 0) {
    return ringToCoordinates(element.geometry);
  }
  if (element.members) {
    const segments = element.members.filter((member) => (member.role === "outer" || member.role === "") && member.geometry).map((member) => ringToCoordinates(member.geometry ?? []));
    if (segments.length > 0) {
      return largestRing(assembleRings(segments));
    }
  }
  return void 0;
}
__name(elementRing, "elementRing");
function humanText(tags) {
  const text = (tags.description ?? tags.note ?? "").trim();
  return text || void 0;
}
__name(humanText, "humanText");
function isLatinToken(token) {
  const letters = token.match(new RegExp("\\p{L}", "gu"));
  if (!letters) {
    return /[0-9]/.test(token);
  }
  return letters.every((letter) => new RegExp("\\p{Script=Latin}", "u").test(letter));
}
__name(isLatinToken, "isLatinToken");
function latinize(text) {
  return text.split(/\s+/).filter((token) => token.length > 0 && isLatinToken(token)).join(" ").trim();
}
__name(latinize, "latinize");
function englishName(tags) {
  const candidates = [tags["name:en"], tags.int_name, tags.name];
  for (const candidate of candidates) {
    const cleaned = latinize((candidate ?? "").trim());
    if (cleaned) {
      return cleaned;
    }
  }
  return "";
}
__name(englishName, "englishName");
function mapSurface(surface) {
  if (!surface) {
    return "unknown";
  }
  const value = surface.toLowerCase();
  if (["asphalt", "paved", "bitumen", "tartan"].includes(value)) {
    return "asphalt";
  }
  if (["concrete", "concrete:plates", "paving_stones"].includes(value)) {
    return "concrete";
  }
  if (value === "grass") {
    return "grass";
  }
  if (["gravel", "fine_gravel", "unpaved", "compacted", "ground", "dirt", "earth", "sand"].includes(value)) {
    return "gravel";
  }
  return "unknown";
}
__name(mapSurface, "mapSurface");
function parseDesignator(part) {
  const match = part.trim().toUpperCase().match(/^(\d{1,2})([LRC]?)$/);
  if (!match) {
    return void 0;
  }
  const number = parseInt(match[1], 10);
  if (number < 1 || number > 36) {
    return void 0;
  }
  return { designator: match[1].padStart(2, "0") + match[2], heading: number * 10 };
}
__name(parseDesignator, "parseDesignator");
function buildRunways(element) {
  const tags = element.tags ?? {};
  const ring = elementRing(element);
  if (!ring || ring.length < 2) {
    return [];
  }
  const length = toInteger(tags.length);
  const width = toInteger(tags.width);
  if (length === void 0 || width === void 0) {
    return [];
  }
  const designators = (tags.ref ?? "").split("/").map((part) => parseDesignator(part)).filter((value) => value !== void 0);
  if (designators.length === 0) {
    return [];
  }
  const surfaceType = mapSurface(tags.surface);
  const elevation = toInteger(tags.ele);
  return designators.map(({ designator, heading }) => {
    const threshold2 = thresholdEndpointFor(heading, ring);
    const opposite = threshold2 === ring[0] ? ring[ring.length - 1] : ring[0];
    const runway = {
      designator,
      length,
      width,
      magneticHeading: heading,
      trueHeading: Math.round(initialBearing(threshold2, opposite)),
      surfaceType,
      lightingType: "unknown",
      coordinates: threshold2
    };
    if (elevation !== void 0) {
      runway.elevation = elevation;
    }
    return runway;
  });
}
__name(buildRunways, "buildRunways");
function buildTerminal(element) {
  const tags = element.tags ?? {};
  const name = englishName(tags);
  const ref = (tags.ref ?? "").trim();
  if (!name && !ref) {
    return void 0;
  }
  const ring = elementRing(element);
  const centroid = ring && ring.length > 0 ? polygonCentroid(ring) : nodeLocation(element);
  if (!centroid) {
    return void 0;
  }
  const terminal = {
    shortName: deriveTerminalShortName(ref, name),
    fullName: name || ref,
    averageTaxiTime: 0,
    operatorCodes: []
  };
  const text = humanText(tags);
  if (text) {
    terminal.text = text;
  }
  if (ring && ring.length >= 3) {
    terminal.shape = ring;
  }
  return { osmId: element.id, centroid, terminal };
}
__name(buildTerminal, "buildTerminal");
function elementPoint(element) {
  const node = nodeLocation(element);
  if (node) {
    return node;
  }
  if (element.geometry && element.geometry.length > 0) {
    const last = element.geometry[element.geometry.length - 1];
    return { longitude: last.lon, latitude: last.lat };
  }
  return void 0;
}
__name(elementPoint, "elementPoint");
function namedPoint(element) {
  const ref = (element.tags?.ref ?? element.tags?.name ?? "").trim();
  if (!ref) {
    return void 0;
  }
  const coordinates = elementPoint(element);
  if (!coordinates) {
    return void 0;
  }
  return { name: ref, coordinates };
}
__name(namedPoint, "namedPoint");
function buildParkingPosition(element) {
  const point = namedPoint(element);
  if (!point) {
    return void 0;
  }
  return {
    name: point.name,
    bridge: "no",
    stairs: "no",
    deicing: "no",
    gpu: "no",
    pca: "no",
    type: "straight-in",
    spotType: "other",
    assistance: "none",
    location: "remote",
    noiseSensitivity: "no",
    fuelingOptions: "none",
    coordinates: point.coordinates
  };
}
__name(buildParkingPosition, "buildParkingPosition");
function buildGate(element) {
  const point = namedPoint(element);
  if (!point) {
    return void 0;
  }
  return {
    name: point.name,
    category: "international",
    parkingPosition: null,
    coordinates: point.coordinates
  };
}
__name(buildGate, "buildGate");
function selectAerodrome(elements) {
  const aerodromes = elements.filter((element) => element.tags?.aeroway === "aerodrome");
  const withRing = aerodromes.find((element) => {
    const ring = elementRing(element);
    return ring !== void 0 && ring.length >= 3;
  });
  return withRing ?? aerodromes[0];
}
__name(selectAerodrome, "selectAerodrome");
function linkGatesToStands(gates, positions) {
  const byName = new Map(positions.map((position) => [position.name, position]));
  const withinReach = /* @__PURE__ */ __name((gate, position) => haversineMeters(gate.coordinates, position.coordinates) <= MAX_GATE_STAND_DISTANCE_METERS, "withinReach");
  for (const gate of gates) {
    const sameName = byName.get(gate.name);
    const nearest = nearestByPoint(gate.coordinates, positions, (position) => position.coordinates);
    const target = sameName && withinReach(gate, sameName) ? sameName : nearest && withinReach(gate, nearest) ? nearest : void 0;
    if (target) {
      gate.parkingPosition = target.name;
      target.location = "gate";
    }
  }
}
__name(linkGatesToStands, "linkGatesToStands");
function transformAirport(icaoCode, elements) {
  const result = {
    icaoCode: icaoCode.toUpperCase(),
    name: null,
    runways: [],
    terminals: [],
    parkingPositions: [],
    gates: []
  };
  const aerodrome = selectAerodrome(elements);
  if (aerodrome) {
    result.name = shortenAirportName(englishName(aerodrome.tags ?? {})) || null;
    const ring = elementRing(aerodrome);
    if (ring && ring.length >= 3) {
      result.shape = ring;
      result.location = polygonCentroid(ring);
    } else {
      result.location = nodeLocation(aerodrome) ?? (ring ? polygonCentroid(ring) : void 0);
    }
  }
  const runwaysByDesignator = /* @__PURE__ */ new Map();
  const terminalsByShortName = /* @__PURE__ */ new Map();
  const parkingPositionsByName = /* @__PURE__ */ new Map();
  const gatesByName = /* @__PURE__ */ new Map();
  for (const element of elements) {
    const aeroway = element.tags?.aeroway;
    if (aeroway === "runway") {
      for (const runway of buildRunways(element)) {
        if (!runwaysByDesignator.has(runway.designator)) {
          runwaysByDesignator.set(runway.designator, runway);
        }
      }
    } else if (aeroway === "terminal") {
      const terminal = buildTerminal(element);
      if (terminal) {
        const shortName = uniqueShortName(terminal.terminal.shortName, new Set(terminalsByShortName.keys()));
        terminal.terminal.shortName = shortName;
        terminalsByShortName.set(shortName, terminal);
      }
    } else if (aeroway === "parking_position") {
      const position = buildParkingPosition(element);
      if (position && !parkingPositionsByName.has(position.name)) {
        parkingPositionsByName.set(position.name, position);
      }
    } else if (aeroway === "gate") {
      const gate = buildGate(element);
      if (gate && !gatesByName.has(gate.name)) {
        gatesByName.set(gate.name, gate);
      }
    }
  }
  result.runways = [...runwaysByDesignator.values()];
  result.terminals = [...terminalsByShortName.values()];
  result.parkingPositions = [...parkingPositionsByName.values()];
  result.gates = [...gatesByName.values()];
  linkGatesToStands(result.gates, result.parkingPositions);
  return result;
}
__name(transformAirport, "transformAirport");

// src/types.ts
var SECTIONS = ["location", "shape", "runways", "terminals", "parkingPositions", "gates"];

// src/handler.ts
var MAX_RESULT_BYTES = 9e5;
var ALLOWED_METHODS = ["get", "post"];
var ICAO_PATTERN = /^[A-Z]{4}$/;
var logger = new Logger("PullHandler");
function requireMethod(params) {
  const used = (params.__ow_method ?? "get").toLowerCase();
  if (!ALLOWED_METHODS.includes(used)) {
    throw new MethodNotAllowedError(used, ALLOWED_METHODS);
  }
}
__name(requireMethod, "requireMethod");
function requireIcao(params) {
  const raw = params.icao;
  if (typeof raw !== "string" || raw.trim() === "") {
    throw new BadRequestError("Parameter icao is required, for example icao=EDDF.");
  }
  const icao = raw.trim().toUpperCase();
  if (!ICAO_PATTERN.test(icao)) {
    throw new BadRequestError(`"${raw}" is not an ICAO code. Expected four letters, for example EDDF.`);
  }
  return icao;
}
__name(requireIcao, "requireIcao");
function parseSections(params) {
  const raw = params.include;
  if (raw === void 0 || raw === null || raw === "") {
    return void 0;
  }
  const requested = (Array.isArray(raw) ? raw : String(raw).split(",")).map((entry) => String(entry).trim()).filter(Boolean);
  if (requested.length === 0) {
    return void 0;
  }
  const unknown = requested.filter((entry) => !SECTIONS.includes(entry));
  if (unknown.length > 0) {
    throw new BadRequestError(
      `Unknown include section(s): ${unknown.join(", ")}. Expected any of ${SECTIONS.join(", ")}.`
    );
  }
  return requested;
}
__name(parseSections, "parseSections");
function project(data, sections) {
  const projected = {
    icaoCode: data.icaoCode,
    name: data.name,
    source: data.source
  };
  for (const section of sections) {
    if (data[section] !== void 0) {
      projected[section] = data[section];
    }
  }
  return projected;
}
__name(project, "project");
function guardResultSize(body) {
  const bytes = Buffer.byteLength(JSON.stringify(body) ?? "", "utf8");
  if (bytes > MAX_RESULT_BYTES) {
    throw new ResultTooLargeError(bytes, MAX_RESULT_BYTES);
  }
}
__name(guardResultSize, "guardResultSize");
function describeRequest(icao, sections) {
  return `icao=${icao}${sections ? ` include=${sections.join(",")}` : ""}`;
}
__name(describeRequest, "describeRequest");
async function handleRequest(client2, params) {
  const startedAt = Date.now();
  let request = "unparsed";
  try {
    requireMethod(params);
    const icao = requireIcao(params);
    const sections = parseSections(params);
    request = describeRequest(icao, sections);
    const data = assembleAirportData(transformAirport(icao, await client2.queryAerodrome(icao)));
    if (isEmpty(data)) {
      throw new AerodromeNotFoundError(icao);
    }
    const body = { airport: sections ? project(data, sections) : data };
    guardResultSize(body);
    logger.log(
      `Served ${request} in ${Date.now() - startedAt}ms: ${data.runways.length} runways, ${data.terminals.length} terminals, ${data.parkingPositions.length} parking positions, ${data.gates.length} gates.`
    );
    return { statusCode: 200, body };
  } catch (error) {
    if (error instanceof ProviderError) {
      logger.warn(
        `Request ${request} failed after ${Date.now() - startedAt}ms with ${error.status} ${error.code}: ${error.message}`
      );
      return {
        statusCode: error.status,
        body: {
          error: {
            code: error.code,
            message: error.message,
            status: error.status
          }
        }
      };
    }
    logger.error(
      `Request ${request} crashed after ${Date.now() - startedAt}ms: ${describeError(error)}`,
      stackOf(error)
    );
    return {
      statusCode: 500,
      body: {
        error: {
          code: "INTERNAL_ERROR",
          message: "Airport lookup failed.",
          status: 500
        }
      }
    };
  }
}
__name(handleRequest, "handleRequest");

// src/function.ts
var DEFAULT_USER_AGENT = "flight-tracker-osm-provider (+https://api.flights.barcz.me)";
var logger2 = new Logger("PullFunction");
var client;
function resolveUrls() {
  const configured = (process.env.OVERPASS_URL ?? "").split(",").map((url) => url.trim()).filter(Boolean);
  return configured.length > 0 ? configured : DEFAULT_OVERPASS_URLS;
}
__name(resolveUrls, "resolveUrls");
function resolveClient() {
  if (!client) {
    const urls = resolveUrls();
    client = new OverpassClient({
      urls,
      // Overpass' usage policy asks for an identifying User-Agent.
      userAgent: process.env.OSM_USER_AGENT ?? DEFAULT_USER_AGENT
    });
    logger2.log(`Cold start. Reading OpenStreetMap through ${urls.join(", ")}.`);
  }
  return client;
}
__name(resolveClient, "resolveClient");
async function main(args) {
  const { statusCode, body } = await handleRequest(resolveClient(), args ?? {});
  return {
    statusCode,
    headers: { "Content-Type": "application/json" },
    body
  };
}
__name(main, "main");

// src/lambda.ts
var PULL_PATH = "/pull";
var SECRET_HEADER = "x-require-whisk-auth";
var logger3 = new Logger("PullLambda");
function authorised(given) {
  const secret = process.env.OSM_FUNCTION_SECRET ?? "";
  if (secret === "") {
    logger3.error("OSM_FUNCTION_SECRET is not set, so every request is refused.");
    return false;
  }
  if (given === void 0) {
    return false;
  }
  const expected = Buffer.from(secret, "utf8");
  const actual = Buffer.from(given, "utf8");
  return expected.length === actual.length && (0, import_node_crypto.timingSafeEqual)(expected, actual);
}
__name(authorised, "authorised");
function refuse(error) {
  logger3.warn(`Refused with ${error.status} ${error.code}: ${error.message}`);
  return {
    statusCode: error.status,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ error: { code: error.code, message: error.message, status: error.status } })
  };
}
__name(refuse, "refuse");
async function handler(event) {
  if (!authorised(event.headers?.[SECRET_HEADER])) {
    return refuse(new UnauthorizedError());
  }
  if (event.rawPath !== PULL_PATH) {
    return refuse(new RouteNotFoundError(event.rawPath, PULL_PATH));
  }
  const result = await main({
    ...event.queryStringParameters,
    __ow_method: event.requestContext.http.method.toLowerCase()
  });
  return {
    statusCode: result.statusCode,
    headers: result.headers,
    body: typeof result.body === "string" ? result.body : JSON.stringify(result.body)
  };
}
__name(handler, "handler");
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  PULL_PATH,
  handler
});
